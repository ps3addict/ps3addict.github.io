HEN 3.0.3 (NOAU)

Mod by Coro

Patches applied:

* Auto-Update Via Internet Disabled

USE AT YOUR OWN RISK!!!

This zip is just the PS3HEN.BIN files for each firmware. You can use these BINs in your own mods.

MD5 File Hashes

VER	4.88
MD5	37CC386EDCECBC78E576D229347267D7

VER	4.87
MD5	5C355B1006862CF5EB4B976E1BCF7A24

VER	4.86
MD5	CB916B7D9BD1BC08750DA881332AEB93

VER	4.85
MD5	E3BF46D35DDFD3248552E8CF63C6478A

VER	4.84
MD5	231689CD87907E30CB5FB38EF103DFFA

Thanks to PS3Xploit Team for HEN! Thanks to Joonie, habib, and zecoxao for HFW!
