HEN 3.0.3 (BTGA)

Mod by Coro

Patches applied:

* BT/USB Game Audio Enabled
* Auto-Update Via Internet Disabled

USE AT YOUR OWN RISK!!!

Only use a package that matches your firmware version!

Do NOT use with Sony BT (Pulse)!

Install the appropriate pkg after enableing HEN. Then reboot and enable HEN again. Instead of displaying "Welcome to HEN 3.0.3", you should see now "HEN 3.0.3 (BTGA)"

To remove the mod, install apporpriate "restore" pkg.

MD5 File Hashes

VER	4.88
MD5	37A5196064BEA8CAA543A23415081A9E

VER	4.87
MD5	70E2D918EA9D04C15C047081713F3F16

VER	4.86
MD5	193DA8F95DEB978A230426BE9D101205

VER	4.85
MD5	D82F9006FB70E9139C7FF8E8551A2486

VER	4.84
MD5	8E68A727FE3FF1D67D018100876AA507

Instructions:

You must enable HEN before you can use a bluetooth sound device! After enabling HEN and registering the device, goto "Audio Device Settings". Change "Output Device" to your bluetooth device. Make sure you select "OK" when done! If you press circle, the changes will not be saved!

If your BT is connected but there is no sound in game, press PS and goto "Accessory Settings", "Manage Bluetooth Devices", highlight your device, press triangle, and select connect. You may have to exit game, connect, then start game again...

Auto-updates are disabled so that you will not lose the mod when HEN is updated in the future.

Thanks to PS3Xploit Team for HEN! Thanks to Joonie, habib, and zecoxao for HFW! Thanks to Louay for his previous releases!