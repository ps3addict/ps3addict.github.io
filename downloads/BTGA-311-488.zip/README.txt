HEN 3.1.1 (BTGA)

Mod by Coro

Changes from official HEN:
BT/USB Game Audio Enabled

USE AT YOUR OWN RISK!!!

Only use a package that matches your firmware version!

Do NOT use with Sony BT (Pulse) Headphones! This feature was removed from official HEN because of incompatability with that device!

Please note that sound quality is poor because of the way the hack works. There is no way to improve it. USB devices will have better sound quality than bluetooth ones. Some bluetooth devices may not work or have issues. For example, my earbuds have to be deleted and re-registered every time I turn on my PS3.

---------

Install the appropriate pkg after enableing HEN. Then reboot and enable HEN again. Instead of displaying "Welcome to HEN 3.1.1", you should now see "HEN 3.1.1 (BTGA)"

To remove the mod, reinstall HEN. (Installing HFW again is not needed.)

MD5 File Hashes

VER	4.89
MD5 D61C560013E0DB6EB4162D118605F259

VER	4.88
MD5 5D6CDACD68C858A1D85E91A4DA25FBF8

VER	4.87
MD5 08B19585E563976472B948811F71D84B

VER	4.86
MD5 87839E8EDBEF8F571D502C4157CD62EE

VER	4.85
MD5 F95305163B310D5701D78B5FFF383B7F

VER	4.84
MD5 855D881BB6DD2E8BECF93A46C2D602BA

---------

Instructions:

You must enable HEN before you can use a bluetooth sound device to hear game audio (intead of voice chat). When registering the device, you may be asked for a PIN code that you do not need for Android or other systems. Try "0000", "1111", and an empty code if your device does not normally ask for one. To change from TV speakers to your device, goto "Audio Device Settings". Change "Output Device" to your bluetooth device. Make sure you select "OK" when done! If you press circle, the changes will not be saved!

If your BT is turned on but there is no sound in game, press PS and goto "Accessory Settings", "Manage Bluetooth Devices", highlight your device, press triangle, and select "Connect". You may have to exit game, connect, then start the game again...

---------

I recommend that you disable automatic HEN updates in HFW Tools so that you will not lose the mod when HEN is updated again. I am hoping that a future HEN will have turning on BT/USB game audio as an option in HFW Tools.

Thanks to PS3Xploit Team and all others who contributed to HEN!

Thanks to Joonie, habib, zecoxao, and littlebalup for HFW!

Thanks to Louay for his previous HEN and CFW BT/USB game audio releases!

Thanks to ZerOxFF for the original CFW mod. For more info on how the mod works, see his blog post at:

https://blog.madnation.net/ps3-bt-usb-audio-passthrough/
